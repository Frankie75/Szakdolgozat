﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Car_Rent_All.Models
{
    public class RoleName
    {
        public const string CanManage = "CanManage";
    }
}