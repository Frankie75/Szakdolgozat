﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Car_Rent_All.DTOS
{
    public class ValtoDTO
    {
        public int Id { get; set; }
        public string Nev { get; set; }
    }
}