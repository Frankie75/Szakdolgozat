﻿using Car_Rent_All.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Car_Rent_All.ViewModels
{
    public class JarmuUgyfelViewModel
    {
        public Ugyfel Ugyfel { get; set; }
        public Jarmu Jarmu { get; set; }
    }
}